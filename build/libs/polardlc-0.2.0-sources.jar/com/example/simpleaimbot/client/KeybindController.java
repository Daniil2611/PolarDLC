package com.example.simpleaimbot.client;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.freelook.freelook.FreeLookMod;
import com.example.simpleaimbot.gui.imgui.ImGuiSettingsScreen;
import com.example.simpleaimbot.modules.KillAura;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

public final class KeybindController {
    private boolean wasTriggerKeyPressed;
    private boolean wasKillauraKeyPressed;
    private boolean wasFreeLookPressed;

    public void handle(class_310 client, class_304 openSettingsKey) {
        while (openSettingsKey.method_1436()) {
            client.method_1507(new ImGuiSettingsScreen());
        }

        if (client.field_1755 != null) {
            return;
        }

        long windowHandle = client.method_22683().method_4490();
        ModConfig config = ConfigManager.getConfig();
        handleTriggerbotToggle(client, config, windowHandle);
        handleKillAuraToggle(client, config, windowHandle);
        handleFreeLookToggle(client, config, windowHandle);
    }

    private void handleTriggerbotToggle(class_310 client, ModConfig config, long windowHandle) {
        if (config.triggerbotKeyCode == -1) {
            wasTriggerKeyPressed = false;
            return;
        }

        boolean triggerPressed = class_3675.method_15987(windowHandle, config.triggerbotKeyCode);
        if (triggerPressed && !wasTriggerKeyPressed) {
            boolean wasEnabled = config.triggerbotEnabled;
            if (config.killauraEnabled) {
                config.killauraEnabled = false;
            }
            config.triggerbotEnabled = !wasEnabled;
            ConfigManager.save();
            sendStatus(client, "Triggerbot", config.triggerbotEnabled);
        }
        wasTriggerKeyPressed = triggerPressed;
    }

    private void handleKillAuraToggle(class_310 client, ModConfig config, long windowHandle) {
        if (config.killauraKeyCode == -1) {
            wasKillauraKeyPressed = false;
            return;
        }

        boolean killAuraPressed = class_3675.method_15987(windowHandle, config.killauraKeyCode);
        if (killAuraPressed && !wasKillauraKeyPressed) {
            boolean wasEnabled = config.killauraEnabled;
            if (!wasEnabled) {
                config.triggerbotEnabled = false;
            }
            config.killauraEnabled = !wasEnabled;
            ConfigManager.save();
            if (!config.killauraEnabled) {
                KillAura.reset();
            }
            sendStatus(client, "KillAura", config.killauraEnabled);
        }
        wasKillauraKeyPressed = killAuraPressed;
    }

    private void handleFreeLookToggle(class_310 client, ModConfig config, long windowHandle) {
        boolean freeLookPressed = class_3675.method_15987(windowHandle, config.freeLookKeyCode);
        if (config.freeLookToggle) {
            if (freeLookPressed && !wasFreeLookPressed) {
                if (FreeLookMod.isManualFreeLooking) {
                    FreeLookMod.stopManualFreeLooking(client);
                } else {
                    FreeLookMod.startManualFreeLooking(client);
                }
            }
        } else {
            if (freeLookPressed && !FreeLookMod.isManualFreeLooking) {
                FreeLookMod.startManualFreeLooking(client);
            } else if (!freeLookPressed && FreeLookMod.isManualFreeLooking) {
                FreeLookMod.stopManualFreeLooking(client);
            }
        }
        wasFreeLookPressed = freeLookPressed;
    }

    private void sendStatus(class_310 client, String moduleName, boolean enabled) {
        if (client.field_1724 != null) {
            client.field_1724.method_7353(class_2561.method_43470(moduleName + " " + (enabled ? "enabled" : "disabled")), true);
        }
    }
}

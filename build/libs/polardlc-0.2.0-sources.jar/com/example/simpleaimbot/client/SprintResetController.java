package com.example.simpleaimbot.client;

import net.minecraft.class_1657;
import net.minecraft.class_310;

public final class SprintResetController {
    private SprintResetController() {
    }

    public static boolean disableSprint(class_310 client, class_1657 player) {
        if (player == null || !player.method_5624()) {
            return false;
        }

        player.method_5728(false);
        client.field_1690.field_1867.method_23481(false);
        return true;
    }

    public static void enableSprint(class_310 client, class_1657 player, boolean shouldRestore) {
        if (!shouldRestore || player == null) {
            return;
        }

        player.method_5728(true);
        client.field_1690.field_1867.method_23481(true);
    }
}

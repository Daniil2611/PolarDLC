package com.example.simpleaimbot.client;

import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.utils.InventoryMoveHelper;
import org.slf4j.Logger;

import java.util.Random;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_490;
import net.minecraft.class_746;

public final class MovementController {
    private static final Random RANDOM = new Random();
    private int sprintDelay;
    private int totemDelayTicks = 3;

    public void tick(class_310 client, ModConfig config, long lastCombatAttackTime, long lastSprintResetTime, Logger logger) {
        if (client.field_1724 == null) {
            return;
        }

        handleFullbright(client, config);
        handleMovementModules(client, config);
        handleInventoryMove(client, config);
        InventoryMoveHelper.tick();
        handleAutoTotem(client, config, logger);
    }

    private void handleFullbright(class_310 client, ModConfig config) {
        if (client.field_1724 == null) {
            return;
        }

        if (config.fullbrightEnabled) {
            client.field_1724.method_6092(new class_1293(class_1294.field_5925, 9999 * 20, 0, false, false, true));
        } else {
            client.field_1724.method_6016(class_1294.field_5925);
        }
    }

    private void handleMovementModules(class_310 client, ModConfig config) {
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }

        if (config.flyEnabled && !player.method_7337() && !player.method_7325()) {
            player.method_31549().field_7478 = true;
        } else if (!config.flyEnabled && !player.method_7337() && !player.method_7325() && !player.method_31549().field_7479) {
            player.method_31549().field_7478 = false;
        }

        if (!config.autoSprintEnabled) {
            sprintDelay = 0;
            return;
        }

        boolean movingForward = client.field_1690.field_1894.method_1434();
        if (movingForward
                && !player.method_5624()
                && !player.method_5715()
                && player.method_7344().method_7586() > 6) {
            if (sprintDelay == 0) {
                player.method_5728(true);
                sprintDelay = RANDOM.nextInt(1, 4);
            }
        } else if (!movingForward && player.method_5624()) {
            player.method_5728(false);
            sprintDelay = 0;
        }

        if (sprintDelay > 0) {
            sprintDelay--;
        }
    }

    private void handleInventoryMove(class_310 client, ModConfig config) {
        // Убрана проверка на одиночную игру
        if (!config.inventoryMoveEnabled
                || client.field_1755 == null
                || client.field_1755 instanceof class_408
                || client.field_1724 == null) {
            return;
        }

        long windowHandle = client.method_22683().method_4490();
        int forwardCode = client.field_1690.field_1894.method_1429().method_1444();
        int backCode = client.field_1690.field_1881.method_1429().method_1444();
        int leftCode = client.field_1690.field_1913.method_1429().method_1444();
        int rightCode = client.field_1690.field_1849.method_1429().method_1444();
        int jumpCode = client.field_1690.field_1903.method_1429().method_1444();
        int sprintCode = client.field_1690.field_1867.method_1429().method_1444();

        client.field_1690.field_1894.method_23481(class_3675.method_15987(windowHandle, forwardCode));
        client.field_1690.field_1881.method_23481(class_3675.method_15987(windowHandle, backCode));
        client.field_1690.field_1913.method_23481(class_3675.method_15987(windowHandle, leftCode));
        client.field_1690.field_1849.method_23481(class_3675.method_15987(windowHandle, rightCode));
        client.field_1690.field_1903.method_23481(class_3675.method_15987(windowHandle, jumpCode));
        client.field_1690.field_1867.method_23481(class_3675.method_15987(windowHandle, sprintCode));

        int sneakCode = client.field_1690.field_1832.method_1429().method_1444();
        client.field_1724.method_5660(class_3675.method_15987(windowHandle, sneakCode));
    }

    private void handleAutoTotem(class_310 client, ModConfig config, Logger logger) {
        class_746 player = client.field_1724;
        if (player == null) {
            return;
        }

        if (!config.autoTotemEnabled) {
            totemDelayTicks = 0;
            return;
        }

        if (totemDelayTicks > 0) {
            totemDelayTicks--;
            return;
        }

        if (player.method_6032() > config.autoTotemThreshold) {
            return;
        }

        class_1799 offhand = player.method_6079();
        if (offhand.method_7909() == class_1802.field_8288 || client.field_1761 == null) {
            return;
        }

        int slot = findTotemInInventory(player, logger);
        if (slot == -1) {
            return;
        }

        boolean wasScreenOpen = client.field_1755 != null;
        if (!wasScreenOpen) {
            client.method_1507(new class_490(player));
        }

        int screenSlot = slot < 9 ? slot + 36 : slot;
        int offhandScreenSlot = 45;
        int syncId = player.field_7512.field_7763;
        client.field_1761.method_2906(syncId, screenSlot, 0, class_1713.field_7790, player);
        client.field_1761.method_2906(syncId, offhandScreenSlot, 0, class_1713.field_7790, player);
        client.field_1761.method_2906(syncId, screenSlot, 0, class_1713.field_7790, player);
        totemDelayTicks = config.autoTotemDelay;
        logger.info("[AutoTotem] Swapped totem from slot {} to offhand", slot);

        if (!wasScreenOpen) {
            client.method_1507(null);
        }
    }

    private static int findTotemInInventory(class_746 player, Logger logger) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8288 && stack.method_58657().method_57543()) {
                logger.info("Found unenchanted totem at slot {}", i);
                return i;
            }
        }

        for (int i = 0; i < 36; i++) {
            class_1799 stack = player.method_31548().method_5438(i);
            if (stack.method_7909() == class_1802.field_8288) {
                logger.info("Found enchanted totem at slot {}", i);
                return i;
            }
        }

        logger.info("No totem found in inventory.");
        return -1;
    }
}
package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_10142;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class ESPRenderer {
    private static final class_310 CLIENT = class_310.method_1551();

    public static void renderPlayerESP(WorldRenderContext context) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.playerEspEnabled || CLIENT.field_1687 == null || CLIENT.field_1724 == null) {
            return;
        }

        List<class_742> players = new ArrayList<>(CLIENT.field_1687.method_18456());
        float tickDelta = context.tickCounter().method_60637(true);
        float time = System.currentTimeMillis() / 1000.0f;

        for (class_742 player : players) {
            if (player == CLIENT.field_1724 || !player.method_5805()) {
                continue;
            }

            double x = class_3532.method_16436(tickDelta, player.field_6014, player.method_23317());
            double y = class_3532.method_16436(tickDelta, player.field_6036, player.method_23318());
            double z = class_3532.method_16436(tickDelta, player.field_5969, player.method_23321());
            float radius = Math.max(0.32f, player.method_17681() * 0.72f);
            float height = player.method_17682();

            renderCapsule(context, x, y, z, radius, height, config.espColor, config.playerEspFilled, time + player.method_5628() * 0.21f);
        }
    }

    private static void renderCapsule(WorldRenderContext context, double x, double y, double z,
                                      float radius, float height, int color, boolean filled, float time) {
        class_4587 matrices = context.matrixStack();
        if (matrices == null) {
            return;
        }

        class_243 cameraPos = context.camera().method_19326();
        matrices.method_22903();
        matrices.method_22904(x - cameraPos.field_1352, y - cameraPos.field_1351, z - cameraPos.field_1350);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        float pulse = 0.02f * (float) Math.sin(time * 3.0f);
        float outer = radius + pulse;
        float inner = Math.max(0.05f, outer - 0.08f);
        int topColor = withAlpha(color, 180);
        int bottomColor = withAlpha(color, 84);

        if (filled) {
            class_287 shell = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
            for (int i = 0; i <= 56; i++) {
                double angle = Math.PI * 2 * i / 56.0;
                float px = (float) Math.cos(angle) * inner;
                float pz = (float) Math.sin(angle) * inner;
                shell.method_22918(matrices.method_23760().method_23761(), px, 0.03f, pz).method_39415(withAlpha(color, 22));
                shell.method_22918(matrices.method_23760().method_23761(), px, height, pz).method_39415(withAlpha(color, 54));
            }
            class_286.method_43433(shell.method_60800());
        }

        drawRingBand(matrices.method_23760().method_23761(), inner, outer, 0.05f, bottomColor, withAlpha(color, 0), 56);
        drawRingBand(matrices.method_23760().method_23761(), inner, outer, height, topColor, withAlpha(color, 0), 56);

        class_287 lines = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
        for (int i = 0; i < 4; i++) {
            double angle = Math.PI / 4 + i * Math.PI / 2;
            float px = (float) Math.cos(angle) * inner;
            float pz = (float) Math.sin(angle) * inner;
            lines.method_22918(matrices.method_23760().method_23761(), px, 0.05f, pz).method_39415(bottomColor);
            lines.method_22918(matrices.method_23760().method_23761(), px, height, pz).method_39415(topColor);
        }
        class_286.method_43433(lines.method_60800());

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        matrices.method_22909();
    }

    private static void drawRingBand(Matrix4f matrix, float innerRadius, float outerRadius, float yOffset,
                                     int outerColor, int innerColor, int segments) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 2 * i / segments;
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);
            buffer.method_22918(matrix, x * outerRadius, yOffset, z * outerRadius).method_39415(outerColor);
            buffer.method_22918(matrix, x * innerRadius, yOffset, z * innerRadius).method_39415(innerColor);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }
}

package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.gui.GuiTheme;
import com.example.simpleaimbot.modules.KillAura;
import com.example.simpleaimbot.utils.render.Render2DEngine;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_266;
import net.minecraft.class_267;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_408;
import net.minecraft.class_742;
import net.minecraft.class_7532;
import net.minecraft.class_8685;
import net.minecraft.class_9015;
import net.minecraft.class_9779;

public class TargetHudRenderer {
    private static final class_310 client = class_310.method_1551();
    private static final int WIDTH = 182;
    private static final int HEIGHT = 78;
    private static final int MARGIN_BOTTOM = 88;

    private static final Map<String, DamageRecord> DAMAGE_RECORDS = new HashMap<>();

    private static class DamageRecord {
        float damageValue;
        long timestamp;
        float lastHealth;
    }

    @SuppressWarnings("unused")
    public static void render(class_332 context, class_9779 tickCounter) {
        if (client.field_1755 != null && !(client.field_1755 instanceof class_408)) {
            return;
        }

        ModConfig config = ConfigManager.getConfig();
        if (!config.targetHudEnabled || !config.killauraEnabled) {
            return;
        }

        class_1297 target = KillAura.getTarget();
        if (!(target instanceof class_1309 livingTarget) || !livingTarget.method_5805()) {
            return;
        }

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        int x = screenWidth / 2 - WIDTH / 2;
        int y = screenHeight - HEIGHT - MARGIN_BOTTOM;

        int accent = config.targetHudGlowColor;
        int fill = GuiTheme.withAlpha(GuiTheme.mix(GuiTheme.panel(), 0xFF0B1019, 0.22f), 214);
        int edge = GuiTheme.withAlpha(GuiTheme.mix(accent, GuiTheme.accentBright(), 0.28f), 180);

        Render2DEngine.drawBlurredShadow(context.method_51448(), x, y, WIDTH, HEIGHT, 6, new Color(GuiTheme.withAlpha(accent, 30), true));
        Render2DEngine.drawRound(context.method_51448(), x, y, WIDTH, HEIGHT, 14, new Color(GuiTheme.withAlpha(edge, 150), true));
        Render2DEngine.drawRound(context.method_51448(), x + 1, y + 1, WIDTH - 2.0f, HEIGHT - 2.0f, 13, new Color(fill, true));
        Render2DEngine.drawRound(context.method_51448(), x + 2, y + 2, WIDTH - 4.0f, HEIGHT - 4.0f, 12, new Color(GuiTheme.withAlpha(0xFFFFFFFF, 8), true));

        int faceSize = 42;
        int faceX = x + 10;
        int faceY = y + 10;

        if (livingTarget instanceof class_742 abstractPlayer) {
            class_8685 skinTextures = abstractPlayer.method_52814();
            class_7532.method_52722(context, skinTextures, faceX, faceY, faceSize);
        } else {
            context.method_25294(faceX, faceY, faceX + faceSize, faceY + faceSize, GuiTheme.withAlpha(GuiTheme.panelAlt(), 255));
        }

        DamageRecord record = DAMAGE_RECORDS.get(livingTarget.method_5845());
        if (record != null && record.timestamp > 0) {
            long elapsed = System.currentTimeMillis() - record.timestamp;
            if (elapsed < 220) {
                float intensity = 1.0f - (float) elapsed / 220.0f;
                int overlay = GuiTheme.withAlpha(0xFFFF4D4D, Math.round(90 * intensity));
                context.method_25294(faceX, faceY, faceX + faceSize, faceY + faceSize, overlay);
            }
        }

        int textX = faceX + faceSize + 10;
        int lineY = y + 10;
        int textWidth = WIDTH - (textX - x) - 12;

        context.method_27535(client.field_1772, GuiTheme.uniform(livingTarget.method_5477().getString()), textX, lineY, GuiTheme.text());
        context.method_51439(client.field_1772, GuiTheme.uniform("Target HUD"), textX, lineY + 12, GuiTheme.withAlpha(GuiTheme.accentBright(), 228), false);

        float[] healthData = getHealthFromScoreboard(livingTarget);
        float health = healthData[0];
        float maxHealth = Math.max(healthData[1], 1.0f);
        updateDamageRecord(livingTarget, health, maxHealth);
        float healthPercent = class_3532.method_15363(health / maxHealth, 0.0f, 1.0f);

        int barY = y + 38;
        int barHeight = 8;
        GuiTheme.drawCard(context, textX, barY, textWidth, barHeight,
                GuiTheme.withAlpha(GuiTheme.panelAlt(), 220), GuiTheme.withAlpha(GuiTheme.text(), 24), 5);
        int filledWidth = Math.max(4, Math.round(textWidth * healthPercent));
        Render2DEngine.drawRound(context.method_51448(), textX + 1, barY + 1, Math.max(1, filledWidth - 2), barHeight - 2, 4,
                new Color(GuiTheme.mix(0xFFED6A5E, 0xFF68E89B, healthPercent), true));

        if (record != null && record.damageValue > 0) {
            long elapsed = System.currentTimeMillis() - record.timestamp;
            if (elapsed < 500) {
                float fade = 1.0f - elapsed / 500.0f;
                float damagePercent = Math.min(record.damageValue / maxHealth, Math.max(0.0f, 1.0f - healthPercent));
                int damageWidth = Math.round(textWidth * damagePercent);
                if (damageWidth > 0) {
                    context.method_25294(textX + filledWidth, barY + 1, Math.min(textX + textWidth - 1, textX + filledWidth + damageWidth),
                            barY + barHeight - 1, GuiTheme.withAlpha(0xFFFF5858, Math.round(160 * fade)));
                }
            } else {
                record.damageValue = 0;
            }
        }

        String healthLine = Math.round(health) + " / " + Math.round(maxHealth) + " HP";
        context.method_51439(client.field_1772, GuiTheme.uniform(healthLine), textX, barY + 12, GuiTheme.text(), false);

        String distanceLine = "Dist: " + String.format("%.1f", client.field_1724 != null ? client.field_1724.method_5739(livingTarget) : 0.0f);
        context.method_51439(client.field_1772, GuiTheme.uniform(distanceLine), textX + textWidth - client.field_1772.method_1727(distanceLine), barY + 12,
                GuiTheme.mutedText(), false);

        class_1799 mainHand = livingTarget.method_6047();
        if (!mainHand.method_7960()) {
            context.method_51439(client.field_1772, GuiTheme.uniform("Item"), textX, y + 59, GuiTheme.mutedText(), false);
            context.method_51427(mainHand, textX + 28, y + 55);
        }
    }

    private static void updateDamageRecord(class_1309 target, float currentHealth, float maxHealth) {
        String uuid = target.method_5845();
        DamageRecord record = DAMAGE_RECORDS.get(uuid);
        if (record == null) {
            record = new DamageRecord();
            record.lastHealth = currentHealth;
            DAMAGE_RECORDS.put(uuid, record);
            return;
        }
        if (currentHealth < record.lastHealth) {
            float damage = record.lastHealth - currentHealth;
            if (damage > 0) {
                record.damageValue = Math.min(damage, maxHealth);
                record.timestamp = System.currentTimeMillis();
            }
        }
        record.lastHealth = currentHealth;
    }

    private static float[] getHealthFromScoreboard(class_1309 target) {
        float defaultHealth = target.method_6032() + target.method_6067();
        float maxHealth = target.method_6063();

        class_269 scoreboard = client.field_1687 != null ? client.field_1687.method_8428() : null;
        if (scoreboard == null) {
            return new float[] { defaultHealth, maxHealth };
        }

        String targetName = target.method_5477().getString();
        String cleanName = targetName.replaceAll("§[0-9a-fk-or]", "");
        String[] possibleObjectives = { "health", "hp", "❤", "здоровье", "healthbar", "player_health" };

        for (String objectiveName : possibleObjectives) {
            class_266 objective = scoreboard.method_1170(objectiveName);
            if (objective != null) {
                float[] resolved = resolveScore(scoreboard, objective, targetName, cleanName, maxHealth);
                if (resolved != null) {
                    return resolved;
                }
            }
        }

        for (class_266 objective : scoreboard.method_1151()) {
            float[] resolved = resolveScore(scoreboard, objective, targetName, cleanName, maxHealth);
            if (resolved != null) {
                return resolved;
            }
        }

        return new float[] { defaultHealth, maxHealth };
    }

    private static float[] resolveScore(class_269 scoreboard, class_266 objective, String targetName, String cleanName, float maxHealth) {
        int rawScore = readScore(scoreboard, objective, targetName);
        if (rawScore > 0 && rawScore < 1000) {
            return new float[] { rawScore, maxHealth };
        }

        rawScore = readScore(scoreboard, objective, cleanName);
        if (rawScore > 0 && rawScore < 1000) {
            return new float[] { rawScore, maxHealth };
        }

        return null;
    }

    private static int readScore(class_269 scoreboard, class_266 objective, String name) {
        class_267 score = (class_267) scoreboard.method_55430(class_9015.method_55422(name), objective);
        return score != null ? score.method_55397() : -1;
    }
}

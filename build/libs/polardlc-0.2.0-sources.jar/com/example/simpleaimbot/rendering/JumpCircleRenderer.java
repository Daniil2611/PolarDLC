package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

public class JumpCircleRenderer {
    private static final class_310 CLIENT = class_310.method_1551();
    private static final List<Circle> CIRCLES = new ArrayList<>();
    private static final long CIRCLE_DURATION = 1000L;
    private static final int CIRCLE_SEGMENTS = 64;

    private static boolean wasOnGround = true;

    private static class Circle {
        final class_243 center;
        final long startTime;
        final float radius;
        final int segments;
        final long duration;
        final int baseColor;
        final ModConfig.JumpCircleMode mode;

        Circle(class_243 center, long startTime, float radius, int segments, long duration, int baseColor, ModConfig.JumpCircleMode mode) {
            this.center = center;
            this.startTime = startTime;
            this.radius = radius;
            this.segments = segments;
            this.duration = duration;
            this.baseColor = baseColor;
            this.mode = mode;
        }

        float progress() {
            return Math.min(1.0f, (System.currentTimeMillis() - startTime) / (float) duration);
        }

        boolean isExpired() {
            return System.currentTimeMillis() - startTime >= duration;
        }
    }

    public static void tick(class_310 client) {
        class_1657 player = client.field_1724;
        if (player == null) {
            return;
        }

        boolean onGround = player.method_24828();
        if (!onGround && wasOnGround && player.method_18798().field_1351 > 0.1) {
            addJumpCircle(player.method_19538());
        }
        wasOnGround = onGround;
    }

    private static void addJumpCircle(class_243 center) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.jumpCircleEnabled) {
            return;
        }

        CIRCLES.add(new Circle(
                center,
                System.currentTimeMillis(),
                config.jumpCircleRadius,
                CIRCLE_SEGMENTS,
                CIRCLE_DURATION,
                config.jumpCircleColor,
                config.jumpCircleMode
        ));
    }

    public static void render(WorldRenderContext context) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.jumpCircleEnabled || CIRCLES.isEmpty()) {
            return;
        }

        class_4587 matrices = context.matrixStack();
        if (matrices == null) {
            return;
        }

        class_243 cameraPos = context.camera().method_19326();
        CIRCLES.removeIf(Circle::isExpired);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        for (Circle circle : CIRCLES) {
            matrices.method_22903();
            matrices.method_22904(circle.center.field_1352 - cameraPos.field_1352, circle.center.field_1351 - cameraPos.field_1351 + 0.02, circle.center.field_1350 - cameraPos.field_1350);

            float progress = circle.progress();
            float radius = circle.radius + progress * 0.65f;

            switch (circle.mode) {
                case RING -> drawRing(matrices.method_23760().method_23761(), circle, radius, progress);
                case WAVE -> drawWave(matrices.method_23760().method_23761(), circle, radius, progress);
                case DOUBLE_RING -> drawDoubleRing(matrices.method_23760().method_23761(), circle, radius, progress);
                case DISC -> drawDisc(matrices.method_23760().method_23761(), circle, radius, progress);
            }

            matrices.method_22909();
        }

        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void drawDisc(Matrix4f matrix, Circle circle, float radius, float progress) {
        int centerColor = withAlpha(circle.baseColor, Math.round(120 * (1.0f - progress)));
        int edgeColor = withAlpha(circle.baseColor, Math.round(22 * (1.0f - progress)));

        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        for (int i = 0; i < circle.segments; i++) {
            double angle1 = Math.PI * 2 * i / circle.segments;
            double angle2 = Math.PI * 2 * (i + 1) / circle.segments;
            buffer.method_22918(matrix, 0, 0, 0).method_39415(centerColor);
            buffer.method_22918(matrix, radius * (float) Math.cos(angle1), 0, radius * (float) Math.sin(angle1)).method_39415(edgeColor);
            buffer.method_22918(matrix, radius * (float) Math.cos(angle2), 0, radius * (float) Math.sin(angle2)).method_39415(edgeColor);
        }
        class_286.method_43433(buffer.method_60800());
        drawRingBand(matrix, radius * 0.92f, radius, 0.0f, withAlpha(circle.baseColor, Math.round(180 * (1.0f - progress))), withAlpha(circle.baseColor, 0), circle.segments);
    }

    private static void drawRing(Matrix4f matrix, Circle circle, float radius, float progress) {
        float outer = radius + 0.08f + progress * 0.2f;
        float inner = Math.max(0.05f, outer - 0.12f);
        drawRingBand(matrix, inner, outer, 0.0f, withAlpha(circle.baseColor, Math.round(185 * (1.0f - progress))), withAlpha(circle.baseColor, 0), circle.segments);
    }

    private static void drawWave(Matrix4f matrix, Circle circle, float radius, float progress) {
        float outer = radius + 0.14f;
        float inner = Math.max(0.05f, outer - 0.14f);
        float amplitude = 0.12f * (1.0f - progress);

        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= circle.segments; i++) {
            double angle = Math.PI * 2 * i / circle.segments;
            float wave = (float) Math.sin(angle * 3.0 + progress * 10.0) * amplitude;
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);
            int outerColor = withAlpha(circle.baseColor, Math.round(170 * (1.0f - progress)));
            int innerColor = withAlpha(circle.baseColor, Math.round(26 * (1.0f - progress)));
            buffer.method_22918(matrix, x * outer, wave, z * outer).method_39415(outerColor);
            buffer.method_22918(matrix, x * inner, wave * 0.35f, z * inner).method_39415(innerColor);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static void drawDoubleRing(Matrix4f matrix, Circle circle, float radius, float progress) {
        drawRingBand(matrix, Math.max(0.05f, radius - 0.1f), radius + 0.02f, 0.0f,
                withAlpha(circle.baseColor, Math.round(160 * (1.0f - progress))), withAlpha(circle.baseColor, 0), circle.segments);
        drawRingBand(matrix, Math.max(0.05f, radius * 0.62f - 0.08f), radius * 0.62f + 0.02f, 0.02f,
                withAlpha(circle.baseColor, Math.round(105 * (1.0f - progress))), withAlpha(circle.baseColor, 0), circle.segments);
    }

    private static void drawRingBand(Matrix4f matrix, float innerRadius, float outerRadius, float yOffset,
                                     int outerColor, int innerColor, int segments) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 2 * i / segments;
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);
            buffer.method_22918(matrix, x * outerRadius, yOffset, z * outerRadius).method_39415(outerColor);
            buffer.method_22918(matrix, x * innerRadius, yOffset, z * innerRadius).method_39415(innerColor);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }
}

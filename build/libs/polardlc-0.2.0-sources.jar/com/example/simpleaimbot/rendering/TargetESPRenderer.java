package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.utils.render.TextureStorage;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public class TargetESPRenderer {
    private static final long INIT_TIME = System.currentTimeMillis();
    private static final int THUNDER_SPIRIT_LENGTH = 14;
    private static final int THUNDER_SPIRIT_FACTOR = 8;
    private static final float THUNDER_SPIRIT_SHAKING = 1.8f;
    private static final float THUNDER_SPIRIT_AMPLITUDE = 3.0f;

    public static void render(WorldRenderContext context, class_1297 target) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.targetEspEnabled || target == null || !target.method_5805()) {
            return;
        }

        class_4587 matrices = context.matrixStack();
        if (matrices == null) {
            return;
        }

        float tickDelta = context.tickCounter().method_60637(true);
        class_243 cameraPos = context.camera().method_19326();
        double x = class_3532.method_16436(tickDelta, target.field_6014, target.method_23317()) - cameraPos.field_1352;
        double y = class_3532.method_16436(tickDelta, target.field_6036, target.method_23318()) - cameraPos.field_1351;
        double z = class_3532.method_16436(tickDelta, target.field_5969, target.method_23321()) - cameraPos.field_1350;
        float height = target.method_17682();
        float radius = Math.max(0.42f, target.method_17681() * 0.75f);
        float time = (System.currentTimeMillis() - INIT_TIME) / 1000.0f;

        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        if (config.targetEspMode == ModConfig.TargetEspMode.SPIRITS) {
            RenderSystem.setShader(class_10142.field_53880);
            drawSpirits(context, target, tickDelta, config.targetEspColor);
        } else {
            matrices.method_22903();
            matrices.method_22904(x, y, z);
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableDepthTest();
            RenderSystem.setShader(class_10142.field_53876);
            switch (config.targetEspMode) {
                case RING_STACK -> drawRingStack(matrices.method_23760().method_23761(), radius, height, config.targetEspColor, time);
                case CYLINDER -> drawCylinder(matrices.method_23760().method_23761(), radius, height, config.targetEspColor, time);
                case SPIRAL -> drawSpiral(matrices.method_23760().method_23761(), radius, height, config.targetEspColor, time);
                case SPIRITS -> { }
            }
            matrices.method_22909();
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void drawSpiral(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        float animatedRadius = radius + 0.02f * (float) Math.sin(time * 1.8f);
        int outerColor = withAlpha(baseColor, 122);
        int innerColor = withAlpha(mixColor(baseColor, 0xFFFFFFFF, 0.18f), 34);
        drawCylinderShell(matrix, animatedRadius * 0.72f, height, withAlpha(baseColor, 6), withAlpha(baseColor, 28), 64);

        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= 140; i++) {
            float progress = i / 140.0f;
            double angle = time * 2.3 + progress * Math.PI * 3.9;
            float y = height * (0.08f + progress * 0.84f);
            float localRadius = animatedRadius + 0.02f * (float) Math.sin(time * 1.5f + progress * 6.0f);
            float x = (float) Math.cos(angle) * localRadius;
            float z = (float) Math.sin(angle) * localRadius;
            int localOuter = withAlpha(outerColor, Math.round(34 + 88 * (1.0f - Math.abs(progress - 0.5f) * 1.5f)));
            int localInner = withAlpha(innerColor, Math.round(10 + 28 * (1.0f - Math.abs(progress - 0.5f) * 1.35f)));
            buffer.method_22918(matrix, x * 1.02f, y, z * 1.02f).method_39415(localOuter);
            buffer.method_22918(matrix, x * 0.93f, y + 0.03f, z * 0.93f).method_39415(localInner);
        }
        class_286.method_43433(buffer.method_60800());

        drawRingBand(matrix, Math.max(0.04f, animatedRadius - 0.05f), animatedRadius + 0.03f, 0.06f, withAlpha(baseColor, 88), withAlpha(baseColor, 0), 72);
        drawRingBand(matrix, Math.max(0.04f, animatedRadius - 0.05f), animatedRadius + 0.03f, height, withAlpha(mixColor(baseColor, 0xFFFFFFFF, 0.12f), 118), withAlpha(baseColor, 0), 72);
    }

    private static void drawRingStack(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        drawCylinderShell(matrix, radius * 0.88f, height, withAlpha(baseColor, 4), withAlpha(baseColor, 18), 64);

        for (int i = 0; i < 3; i++) {
            float layer = i / 2.0f;
            float y = height * (0.18f + 0.28f * i) + (float) Math.sin(time * 1.4f + i * 0.8f) * 0.03f;
            float localRadius = radius + 0.015f * i + (float) Math.sin(time * 1.9f + i) * 0.02f;
            int bright = withAlpha(mixColor(baseColor, 0xFFFFFFFF, 0.08f + layer * 0.10f), Math.round(94 + 28 * layer));
            drawRingBand(
                    matrix,
                    Math.max(0.04f, localRadius - 0.04f),
                    localRadius + 0.03f,
                    y,
                    bright,
                    withAlpha(baseColor, 0),
                    72
            );
        }
    }

    private static void drawCylinder(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        float animatedRadius = radius + 0.02f * (float) Math.sin(time * 1.6f);
        drawCylinderShell(matrix, animatedRadius, height, withAlpha(baseColor, 14), withAlpha(baseColor, 72), 72);
        drawRingBand(matrix, Math.max(0.03f, animatedRadius - 0.05f), animatedRadius + 0.03f, 0.04f, withAlpha(baseColor, 94), withAlpha(baseColor, 0), 72);
        drawRingBand(matrix, Math.max(0.03f, animatedRadius - 0.05f), animatedRadius + 0.03f, height, withAlpha(mixColor(baseColor, 0xFFFFFFFF, 0.12f), 132), withAlpha(baseColor, 0), 72);

        float scan = height * (0.16f + 0.68f * ((float) Math.sin(time * 1.4f) * 0.5f + 0.5f));
        drawRingBand(matrix, Math.max(0.03f, animatedRadius - 0.07f), animatedRadius + 0.06f, scan, withAlpha(baseColor, 86), withAlpha(baseColor, 0), 72);
    }

    private static void drawCylinderShell(Matrix4f matrix, float radius, float height, int bottomColor, int topColor, int segments) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 2 * i / segments;
            float x = (float) Math.cos(angle) * radius;
            float z = (float) Math.sin(angle) * radius;
            buffer.method_22918(matrix, x, 0.02f, z).method_39415(bottomColor);
            buffer.method_22918(matrix, x, height, z).method_39415(topColor);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static void drawVerticalBands(Matrix4f matrix, float radius, float height, float time, int baseColor, int count) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        float tau = (float) (Math.PI * 2.0);
        for (int band = 0; band < count; band++) {
            float angle = time + band * (tau / count);
            float x = (float) Math.cos(angle) * radius;
            float z = (float) Math.sin(angle) * radius;
            float tangentX = -(float) Math.sin(angle) * 0.03f;
            float tangentZ = (float) Math.cos(angle) * 0.03f;
            int low = withAlpha(baseColor, 22);
            int high = withAlpha(mixColor(baseColor, 0xFFFFFFFF, 0.12f), 118);
            buffer.method_22918(matrix, x - tangentX, 0.02f, z - tangentZ).method_39415(low);
            buffer.method_22918(matrix, x + tangentX, 0.02f, z + tangentZ).method_39415(low);
            buffer.method_22918(matrix, x + tangentX * 0.55f, height, z + tangentZ * 0.55f).method_39415(high);
            buffer.method_22918(matrix, x - tangentX * 0.55f, height, z - tangentZ * 0.55f).method_39415(high);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static void drawOrbitAccents(Matrix4f matrix, float radius, float y, int count, float size, int color, float phase) {
        RenderSystem.setShader(class_10142.field_53880);
        for (int i = 0; i < count; i++) {
            float angle = phase + i * ((float) (Math.PI * 2.0) / count);
            float x = (float) Math.cos(angle) * radius;
            float z = (float) Math.sin(angle) * radius;
            drawSpiritOrb(matrix, x, y, z, size, color);
        }
        RenderSystem.setShader(class_10142.field_53876);
    }

    // Ported from ThunderHack Recode's Render3DEngine.renderGhosts (GPL-3.0) to match ThunderHackV2 target ESP.
    private static void drawSpirits(WorldRenderContext context, class_1297 target, float tickDelta, int baseColor) {
        class_310 client = class_310.method_1551();
        class_4587 matrices = context.matrixStack();
        if (client.field_1724 == null || matrices == null) {
            return;
        }

        class_243 cameraPos = context.camera().method_19326();
        double targetX = class_3532.method_16436(tickDelta, target.field_6014, target.method_23317()) - cameraPos.field_1352;
        double targetY = class_3532.method_16436(tickDelta, target.field_6036, target.method_23318()) - cameraPos.field_1351;
        double targetZ = class_3532.method_16436(tickDelta, target.field_5969, target.method_23321()) - cameraPos.field_1350;
        float interpolatedAge = (target.field_6012 - 1) + tickDelta;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.class_4535.SRC_ALPHA, GlStateManager.class_4534.ONE);
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_GHOST);

        boolean canSee = client.field_1724.method_6057(target);
        if (canSee) {
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
        } else {
            RenderSystem.disableDepthTest();
        }

        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        for (int arm = 0; arm < 3; arm++) {
            for (int index = 0; index <= THUNDER_SPIRIT_LENGTH; index++) {
                double radians = Math.toRadians((((index / 1.5f) + interpolatedAge) * THUNDER_SPIRIT_FACTOR + (arm * 120)) % (THUNDER_SPIRIT_FACTOR * 360));
                double wave = Math.sin(Math.toRadians(interpolatedAge * 2.5f + index * (arm + 1)) * THUNDER_SPIRIT_AMPLITUDE) / THUNDER_SPIRIT_SHAKING;
                float offset = index / (float) THUNDER_SPIRIT_LENGTH;
                matrices.method_22903();
                matrices.method_22904(
                        targetX + Math.cos(radians) * target.method_17681(),
                        targetY + 1.0 + wave,
                        targetZ + Math.sin(radians) * target.method_17681()
                );
                matrices.method_22907(class_7833.field_40716.rotationDegrees(-context.camera().method_19330()));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(context.camera().method_19329()));

                Matrix4f matrix = matrices.method_23760().method_23761();
                int color = applyOpacity(resolveSpiritParticleColor(baseColor, arm, offset), offset);
                float scale = Math.max(0.24f * offset, 0.2f);

                buffer.method_22918(matrix, -scale, scale, 0.0f).method_22913(0.0f, 1.0f).method_39415(color);
                buffer.method_22918(matrix, scale, scale, 0.0f).method_22913(1.0f, 1.0f).method_39415(color);
                buffer.method_22918(matrix, scale, -scale, 0.0f).method_22913(1.0f, 0.0f).method_39415(color);
                buffer.method_22918(matrix, -scale, -scale, 0.0f).method_22913(0.0f, 0.0f).method_39415(color);
                matrices.method_22909();
            }
        }
        class_286.method_43433(buffer.method_60800());

        if (canSee) {
            RenderSystem.depthMask(true);
            RenderSystem.disableDepthTest();
        } else {
            RenderSystem.enableDepthTest();
        }
    }

    private static void drawRingBand(Matrix4f matrix, float innerRadius, float outerRadius, float yOffset,
                                     int outerColor, int innerColor, int segments) {
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 2 * i / segments;
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);
            buffer.method_22918(matrix, x * outerRadius, yOffset, z * outerRadius).method_39415(outerColor);
            buffer.method_22918(matrix, x * innerRadius, yOffset, z * innerRadius).method_39415(innerColor);
        }
        class_286.method_43433(buffer.method_60800());
    }

    private static void drawSpiritWisp(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                       float width, float height, int centerColor, int edgeColor) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_WISP);
        drawTexturedCross(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
    }

    private static void drawSpiritOrb(Matrix4f matrix, float centerX, float centerY, float centerZ, float size, int color) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_WISP);
        drawTexturedCross(matrix, centerX, centerY, centerZ, size, size, color, withAlpha(color, 0));
    }

    private static void drawSpiritFlame(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                        float width, float height, int color) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_FLAME);
        drawTexturedCross(matrix, centerX, centerY, centerZ, width, height, color, withAlpha(color, 0));
    }

    private static void drawTexturedCross(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                          float width, float height, int centerColor, int edgeColor) {
        drawTexturedPlaneX(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
        drawTexturedPlaneZ(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
    }

    private static void drawTexturedPlaneX(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                           float width, float height, int centerColor, int edgeColor) {
        float halfWidth = width * 0.5f;
        float halfHeight = height * 0.5f;
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        buffer.method_22918(matrix, centerX - halfWidth, centerY - halfHeight, centerZ).method_22913(0.0f, 1.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX - halfWidth, centerY + halfHeight, centerZ).method_22913(0.0f, 0.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX + halfWidth, centerY + halfHeight, centerZ).method_22913(1.0f, 0.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX + halfWidth, centerY - halfHeight, centerZ).method_22913(1.0f, 1.0f).method_39415(centerColor);
        class_286.method_43433(buffer.method_60800());
    }

    private static void drawTexturedPlaneZ(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                           float width, float height, int centerColor, int edgeColor) {
        float halfWidth = width * 0.5f;
        float halfHeight = height * 0.5f;
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
        buffer.method_22918(matrix, centerX, centerY - halfHeight, centerZ - halfWidth).method_22913(0.0f, 1.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX, centerY + halfHeight, centerZ - halfWidth).method_22913(0.0f, 0.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX, centerY + halfHeight, centerZ + halfWidth).method_22913(1.0f, 0.0f).method_39415(centerColor);
        buffer.method_22918(matrix, centerX, centerY - halfHeight, centerZ + halfWidth).method_22913(1.0f, 1.0f).method_39415(centerColor);
        class_286.method_43433(buffer.method_60800());
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private static int applyOpacity(int color, float opacity) {
        int alpha = Math.round(((color >>> 24) & 0xFF) * class_3532.method_15363(opacity, 0.0f, 1.0f));
        return withAlpha(color, alpha);
    }

    private static int resolveSpiritBaseColor(int baseColor) {
        int opaque = 0xFF000000 | (baseColor & 0x00FFFFFF);
        return isNearWhite(opaque) ? 0xFF7A34FF : opaque;
    }

    private static int resolveSpiritParticleColor(int baseColor, int arm, float offset) {
        int root = resolveSpiritBaseColor(baseColor);
        int armColor = switch (arm) {
            case 1 -> mixColor(root, 0xFFFF63F6, 0.18f);
            case 2 -> mixColor(root, 0xFF5D2FFF, 0.25f);
            default -> mixColor(root, 0xFF8E48FF, 0.12f);
        };
        return mixColor(armColor, 0xFFFFFFFF, 0.10f + offset * 0.16f);
    }

    private static boolean isNearWhite(int color) {
        int r = (color >>> 16) & 0xFF;
        int g = (color >>> 8) & 0xFF;
        int b = color & 0xFF;
        return r > 235 && g > 235 && b > 235;
    }

    private static int mixColor(int first, int second, float progress) {
        progress = class_3532.method_15363(progress, 0.0f, 1.0f);
        int r1 = (first >>> 16) & 0xFF;
        int g1 = (first >>> 8) & 0xFF;
        int b1 = first & 0xFF;
        int r2 = (second >>> 16) & 0xFF;
        int g2 = (second >>> 8) & 0xFF;
        int b2 = second & 0xFF;

        int r = Math.round(r1 + (r2 - r1) * progress);
        int g = Math.round(g1 + (g2 - g1) * progress);
        int b = Math.round(b1 + (b2 - b1) * progress);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}

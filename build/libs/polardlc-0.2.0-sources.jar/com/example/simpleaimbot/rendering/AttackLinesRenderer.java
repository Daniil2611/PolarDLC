package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.utils.TargetUtils;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

import java.util.List;

public class AttackLinesRenderer {
    private static final class_310 client = class_310.method_1551();
    private static final int RED = 0xFFFF0000;
    private static final int GREEN = 0xFF00FF00;

    @SuppressWarnings({"ConstantConditions", "deprecation"})
    public static void render(WorldRenderContext context) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.attackLinesEnabled) return;

        class_1657 player = client.field_1724;
        if (player == null || client.field_1687 == null) return;

        double radius = config.aimbotRange;
        float tickDelta = context.tickCounter().method_60637(true);

        double centerX = class_3532.method_16436(tickDelta, player.field_6014, player.method_23317());
        double centerY = class_3532.method_16436(tickDelta, player.field_6036, player.method_23318());
        double centerZ = class_3532.method_16436(tickDelta, player.field_5969, player.method_23321());

        boolean enemyInRange = isEnemyInRange(player, radius, centerX, centerY, centerZ, tickDelta);
        int color = enemyInRange ? GREEN : RED;

        renderCircle(context, centerX, centerY, centerZ, radius, color);
    }

    @SuppressWarnings("ConstantConditions")
    private static boolean isEnemyInRange(class_1657 player, double radius, double centerX, double centerY, double centerZ, float tickDelta) {
        if (client.field_1687 == null) return false;

        class_238 searchBox = new class_238(centerX - radius, centerY - radius, centerZ - radius,
                centerX + radius, centerY + radius, centerZ + radius);
        List<class_1297> entities = client.field_1687.method_8333(player, searchBox,
                entity -> TargetUtils.isValidTarget(player, entity));

        for (class_1297 entity : entities) {
            double ex = class_3532.method_16436(tickDelta, entity.field_6014, entity.method_23317());
            double ey = class_3532.method_16436(tickDelta, entity.field_6036, entity.method_23318());
            double ez = class_3532.method_16436(tickDelta, entity.field_5969, entity.method_23321());

            class_238 entityBox = entity.method_5829().method_989(ex - entity.method_23317(), ey - entity.method_23318(), ez - entity.method_23321());

            double closestX = class_3532.method_15350(centerX, entityBox.field_1323, entityBox.field_1320);
            double closestZ = class_3532.method_15350(centerZ, entityBox.field_1321, entityBox.field_1324);

            double dx = closestX - centerX;
            double dz = closestZ - centerZ;
            double distSq = dx * dx + dz * dz;

            if (distSq <= radius * radius) {
                return true;
            }
        }
        return false;
    }

    private static void renderCircle(WorldRenderContext context, double x, double y, double z, double radius, int color) {
        class_4587 matrices = context.matrixStack();
        if (matrices == null) return;

        class_243 cameraPos = context.camera().method_19326();
        matrices.method_22903();
        matrices.method_22904(x - cameraPos.field_1352, y - cameraPos.field_1351, z - cameraPos.field_1350);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_10142.field_53876);
        RenderSystem.lineWidth(3.0f);
        RenderSystem.disableDepthTest();

        class_289 tessellator = class_289.method_1348();
        Matrix4f matrix = matrices.method_23760().method_23761();

        int segments = 128;
        class_287 buffer = tessellator.method_60827(class_293.class_5596.field_29345, class_290.field_1576);

        for (int i = 0; i <= segments; i++) {
            double angle = 2 * Math.PI * i / segments;
            double dx = radius * Math.cos(angle);
            double dz = radius * Math.sin(angle);
            buffer.method_22918(matrix, (float) dx, 0.0f, (float) dz).method_39415(color);
        }

        class_286.method_43433(buffer.method_60800());

        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(1.0f);
        RenderSystem.disableBlend();
        matrices.method_22909();
    }
}
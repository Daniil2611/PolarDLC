package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.SimpleAimbotMod;
import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class NametagRenderer {
    private static final Logger LOGGER = LoggerFactory.getLogger(NametagRenderer.class);

    public static void render(class_332 context, class_9779 tickCounter) {
        try {
            class_310 client = class_310.method_1551();
            ModConfig config = ConfigManager.getConfig();

            if (!config.playerEspEnabled) return;

            class_1657 player = client.field_1724;
            if (player == null || client.field_1687 == null) return;

            // Получаем сохранённые из мира матрицы и позицию камеры
            Matrix4f projMatrix = SimpleAimbotMod.getLastProjectionMatrix();
            Matrix4f viewMatrix = SimpleAimbotMod.getLastViewMatrix();
            class_243 cameraPos = SimpleAimbotMod.getLastCameraPos();

            if (projMatrix == null || viewMatrix == null || cameraPos == null) {
                LOGGER.debug("Матрицы ещё не готовы");
                return;
            }

            List<class_1657> targets = new ArrayList<>();
            for (class_1657 target : client.field_1687.method_18456()) {
                if (target == player) continue;
                if (player.method_5739(target) > 75) continue;
                targets.add(target);
            }

            if (targets.isEmpty()) return;

            class_327 textRenderer = client.field_1772;

            // Создаём копии матриц и перемножаем (проекция * вид)
            Matrix4f projCopy = new Matrix4f(projMatrix);
            Matrix4f viewCopy = new Matrix4f(viewMatrix);
            Matrix4f modelViewMatrix = projCopy.mul(viewCopy);

            int screenWidth = client.method_22683().method_4486();
            int screenHeight = client.method_22683().method_4502();

            for (class_1657 target : targets) {
                class_243 targetPos = target.method_19538().method_1031(0, target.method_17682() + 0.5, 0);
                Vector4f clipSpace = worldToScreen(targetPos, cameraPos, modelViewMatrix);

                if (clipSpace == null) continue;

                float invW = 1.0f / clipSpace.w;
                float ndcX = clipSpace.x * invW;
                float ndcY = clipSpace.y * invW;

                int screenX = (int) ((ndcX + 1.0f) / 2.0f * screenWidth);
                int screenY = (int) ((1.0f - ndcY) / 2.0f * screenHeight);

                if (screenX < 0 || screenX > screenWidth || screenY < 0 || screenY > screenHeight) continue;

                class_2561 nameText = class_2561.method_43470(target.method_5477().getString());
                int textWidth = textRenderer.method_27525(nameText);
                context.method_27535(textRenderer, nameText, screenX - textWidth / 2, screenY - 10, 0xFFFFFFFF);
            }
        } catch (Exception e) {
            LOGGER.error("Ошибка при рендеринге ников: {}", e.getMessage());
        }
    }

    private static Vector4f worldToScreen(class_243 worldPos, class_243 cameraPos, Matrix4f modelViewMatrix) {
        Vector4f vec = new Vector4f(
                (float) (worldPos.field_1352 - cameraPos.field_1352),
                (float) (worldPos.field_1351 - cameraPos.field_1351),
                (float) (worldPos.field_1350 - cameraPos.field_1350),
                1.0f
        );
        vec.mul(modelViewMatrix);
        if (vec.w <= 0) return null;
        return vec;
    }
}
package com.example.simpleaimbot.freelook.freelook;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Environment(EnvType.CLIENT)
public class FreeLookMod implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("Freelook");
    public static boolean isFreeLooking = false;
    public static boolean isManualFreeLooking = false;
    private static class_5498 lastPerspective;

    private static boolean interpolating = false;
    private static float startYaw, startPitch;
    private static float targetYaw, targetPitch;
    private static int interpolationTicks = 2;
    private static int currentInterpTick = 0;

    @Override
    public void onInitializeClient() {
        LOGGER.info("FreeLook initialized");
    }

    public static void startManualFreeLooking(class_310 client) {
        if (isManualFreeLooking) return;
        lastPerspective = client.field_1690.method_31044();
        if (lastPerspective == class_5498.field_26664) {
            client.field_1690.method_31043(class_5498.field_26665);
        }
        isManualFreeLooking = true;
        isFreeLooking = true;
    }

    public static boolean isAutoFreeLooking() {
        return isFreeLooking && !isManualFreeLooking;
    }

    public static void stopManualFreeLooking(class_310 client) {
        if (!isManualFreeLooking) return;
        client.field_1690.method_31043(lastPerspective);
        isManualFreeLooking = false;
        isFreeLooking = false;
        // НЕ синхронизируем углы – камера остаётся в последнем положении
    }

    public static void startAutoFreeLooking(class_310 client) {
        if (isManualFreeLooking) return;
        isFreeLooking = true;
    }

    public static void stopAutoFreeLooking(class_310 client) {
        if (isManualFreeLooking) return;
        if (client.field_1724 != null && isFreeLooking) {
            startYaw = client.field_1724.method_36454();
            startPitch = client.field_1724.method_36455();
            if (client.field_1724 instanceof CameraOverriddenEntity cameraEntity) {
                targetYaw = cameraEntity.freelook$getCameraYaw();
                targetPitch = cameraEntity.freelook$getCameraPitch();
                interpolating = true;
                currentInterpTick = 0;
            }
        }
        isFreeLooking = false;
    }

    public static void tick(class_310 client) {
        if (!interpolating) return;
        if (client.field_1724 == null) {
            interpolating = false;
            return;
        }
        currentInterpTick++;
        float progress = (float) currentInterpTick / interpolationTicks;
        if (progress >= 1.0f) {
            client.field_1724.method_36456(targetYaw);
            client.field_1724.method_36457(targetPitch);
            interpolating = false;
            return;
        }
        float newYaw = startYaw + (targetYaw - startYaw) * progress;
        float newPitch = startPitch + (targetPitch - startPitch) * progress;
        client.field_1724.method_36456(newYaw);
        client.field_1724.method_36457(class_3532.method_15363(newPitch, -90.0f, 90.0f));
    }
}

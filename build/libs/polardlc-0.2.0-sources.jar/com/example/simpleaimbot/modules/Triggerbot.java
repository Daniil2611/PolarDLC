package com.example.simpleaimbot.modules;

import com.example.simpleaimbot.client.SprintResetController;
import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.utils.TargetUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_310;
import net.minecraft.class_3966;

public class Triggerbot {
    private static int delay = 0;
    private static final double FIXED_RANGE = 3.0;
    private static final int ATTACK_DELAY_TICKS = 3; // изменено с 5 на 3
    private static long lastAttackTime = 0;
    private static long lastSprintResetTime = 0;

    public static long getLastAttackTime() { return lastAttackTime; }
    public static long getLastSprintResetTime() { return lastSprintResetTime; }

    @SuppressWarnings("ConstantConditions")
    public static void tick(class_310 client) {
        class_1657 player = client.field_1724;
        if (player == null || client.field_1761 == null) return;

        ModConfig config = ConfigManager.getConfig();
        if (!config.triggerbotEnabled) return;

        if (player.method_6115()) return;

        if (delay > 0) {
            delay--;
            return;
        }

        class_239 hit = client.field_1765;
        if (!(hit instanceof class_3966 entityHit)) return;

        class_1297 target = entityHit.method_17782();
        if (!TargetUtils.isValidTarget(player, target)) return;
        if (player.method_5739(target) > FIXED_RANGE) return;

        // Используем getAttackCooldownProgress(1.0f) для точной проверки
        float cooldown = player.method_7261(1.0f);
        if (cooldown < 0.99f) return; // порог 0.99

        if (config.criticals) {
            if (player.method_24828()) return;
            if (player.method_18798().field_1351 >= -0.1) return;
            // Упрощённая проверка падения – без fallTicks/fallStartY
        }

        performAttack(client, player, target);
    }

    private static void performAttack(class_310 client, class_1657 player, class_1297 target) {
        boolean shouldRestoreSprint = preAttackSprintReset(client, player);
        client.field_1761.method_2918(player, target);
        player.method_6104(class_1268.field_5808);
        postAttackSprintReset(client, player, shouldRestoreSprint);
        delay = ATTACK_DELAY_TICKS;
        lastAttackTime = System.currentTimeMillis();
    }

    private static boolean preAttackSprintReset(class_310 client, class_1657 player) {
        if (!SprintResetController.disableSprint(client, player)) {
            return false;
        }

        lastSprintResetTime = System.currentTimeMillis();
        return true;
    }

    private static void postAttackSprintReset(class_310 client, class_1657 player, boolean shouldRestoreSprint) {
        SprintResetController.enableSprint(client, player, shouldRestoreSprint);
    }
}

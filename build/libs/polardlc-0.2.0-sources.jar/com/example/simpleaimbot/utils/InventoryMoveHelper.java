package com.example.simpleaimbot.utils;

import com.example.simpleaimbot.config.ConfigManager;
import java.util.LinkedList;
import java.util.Queue;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_310;

public class InventoryMoveHelper {
    public static final Queue<class_2813> pendingClicks = new LinkedList<>();
    private static int delayTicks = 0;
    public static boolean freezeMovement = false;
    private static boolean closeScheduled = false;

    public static void storePacket(class_2813 packet) {
        pendingClicks.add(packet);
    }

    public static void scheduleClose() {
        if (!pendingClicks.isEmpty()) {
            closeScheduled = true;
        }
    }

    public static void tick() {
        class_310 client = class_310.method_1551();
        if (ConfigManager.getConfig().inventoryMoveEnabled) {
            // Убрана проверка на одиночную игру
            if (client == null) {
                resetState();
                return;
            }

            if (closeScheduled && delayTicks == 0 && !pendingClicks.isEmpty()) {
                delayTicks = 3;
                freezeMovement = true;
                closeScheduled = false;
            } else if (delayTicks > 0) {
                // Блокируем движение
                if (client.field_1724 != null) {
                    client.field_1724.field_3913.field_3905 = 0;
                    client.field_1724.field_3913.field_3907 = 0;
                    client.field_1724.method_6100(false);
                    client.field_1724.method_5660(false);
                    client.field_1724.method_5728(false);
                }
                // Отжимаем клавиши в настройках
                client.field_1690.field_1894.method_23481(false);
                client.field_1690.field_1881.method_23481(false);
                client.field_1690.field_1913.method_23481(false);
                client.field_1690.field_1849.method_23481(false);
                client.field_1690.field_1903.method_23481(false);
                client.field_1690.field_1867.method_23481(false);
                client.field_1690.field_1832.method_23481(false);

                delayTicks--;
                if (delayTicks == 0) {
                    // Отправляем накопленные клики
                    while (!pendingClicks.isEmpty()) {
                        client.method_1562().method_48296().method_10743(pendingClicks.poll());
                    }
                    // Отправляем пакет закрытия инвентаря
                    client.method_1562().method_48296().method_10743(new class_2815(0));
                    freezeMovement = false;
                }
            } else {
                freezeMovement = false;
                closeScheduled = false;
            }
        } else {
            resetState();
        }
    }

    private static void resetState() {
        pendingClicks.clear();
        delayTicks = 0;
        freezeMovement = false;
        closeScheduled = false;
    }
}
package com.example.simpleaimbot.utils.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_10142;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;

import java.awt.*;

public class Render2DEngine {
    private static final class_310 mc = class_310.method_1551();

    public static void drawRect(class_4587 matrices, float x, float y, float width, float height, Color color) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        setupRender();
        RenderSystem.setShader(class_10142.field_53876);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        buffer.method_22918(matrix, x, y + height, 0).method_39415(color.getRGB());
        buffer.method_22918(matrix, x + width, y + height, 0).method_39415(color.getRGB());
        buffer.method_22918(matrix, x + width, y, 0).method_39415(color.getRGB());
        buffer.method_22918(matrix, x, y, 0).method_39415(color.getRGB());
        class_286.method_43433(buffer.method_60800());
        endRender();
    }

    public static void drawRound(class_4587 matrices, float x, float y, float width, float height, float radius, Color color) {
        renderRoundedQuad(matrices, color, x, y, x + width, y + height, radius, 20);
    }

    public static void renderRoundedQuad(class_4587 matrices, Color c, double fromX, double fromY, double toX, double toY, double radius, double samples) {
        setupRender();
        RenderSystem.setShader(class_10142.field_53876);
        renderRoundedQuadInternal(matrices.method_23760().method_23761(), c.getRed()/255f, c.getGreen()/255f, c.getBlue()/255f, c.getAlpha()/255f, fromX, fromY, toX, toY, radius, samples);
        endRender();
    }

    private static void renderRoundedQuadInternal(Matrix4f matrix, float cr, float cg, float cb, float ca, double fromX, double fromY, double toX, double toY, double radius, double samples) {
        class_287 bufferBuilder = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);
        double[][] map = new double[][]{
                {toX - radius, toY - radius, radius},
                {toX - radius, fromY + radius, radius},
                {fromX + radius, fromY + radius, radius},
                {fromX + radius, toY - radius, radius}
        };
        for (int i = 0; i < 4; i++) {
            double[] current = map[i];
            double rad = current[2];
            for (double r = i * 90d; r < (360 / 4d + i * 90d); r += (90 / samples)) {
                float rad1 = (float) Math.toRadians(r);
                float sin = (float) (Math.sin(rad1) * rad);
                float cos = (float) (Math.cos(rad1) * rad);
                bufferBuilder.method_22918(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
            }
            float rad1 = (float) Math.toRadians((360 / 4d + i * 90d));
            float sin = (float) (Math.sin(rad1) * rad);
            float cos = (float) (Math.cos(rad1) * rad);
            bufferBuilder.method_22918(matrix, (float) current[0] + sin, (float) current[1] + cos, 0.0F).method_22915(cr, cg, cb, ca);
        }
        class_286.method_43433(bufferBuilder.method_60800());
    }

    public static void drawBlurredShadow(class_4587 matrices, float x, float y, float width, float height, int blurRadius, Color color) {
        int layers = Math.max(1, Math.min(2, Math.max(1, blurRadius / 4)));
        float radius = Math.max(4.0f, Math.min(width, height) * 0.12f);
        for (int i = layers; i >= 1; i--) {
            float expand = i * 0.85f;
            int alpha = Math.max(2, color.getAlpha() / (10 + i * 5));
            drawRound(matrices,
                    x - expand,
                    y - expand,
                    width + expand * 2.0f,
                    height + expand * 2.0f,
                    radius + expand,
                    new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha));
        }
    }

    public static void horizontalGradient(class_4587 matrices, float x1, float y1, float x2, float y2, Color startColor, Color endColor) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        setupRender();
        RenderSystem.setShader(class_10142.field_53876);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        buffer.method_22918(matrix, x1, y1, 0).method_39415(startColor.getRGB());
        buffer.method_22918(matrix, x1, y2, 0).method_39415(startColor.getRGB());
        buffer.method_22918(matrix, x2, y2, 0).method_39415(endColor.getRGB());
        buffer.method_22918(matrix, x2, y1, 0).method_39415(endColor.getRGB());
        class_286.method_43433(buffer.method_60800());
        endRender();
    }

    public static void verticalGradient(class_4587 matrices, float x1, float y1, float x2, float y2, Color startColor, Color endColor) {
        Matrix4f matrix = matrices.method_23760().method_23761();
        setupRender();
        RenderSystem.setShader(class_10142.field_53876);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
        buffer.method_22918(matrix, x1, y1, 0).method_39415(startColor.getRGB());
        buffer.method_22918(matrix, x1, y2, 0).method_39415(endColor.getRGB());
        buffer.method_22918(matrix, x2, y2, 0).method_39415(endColor.getRGB());
        buffer.method_22918(matrix, x2, y1, 0).method_39415(startColor.getRGB());
        class_286.method_43433(buffer.method_60800());
        endRender();
    }

    public static void setupRender() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public static void endRender() {
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    public static Color injectAlpha(Color color, int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), class_3532.method_15340(alpha, 0, 255));
    }

    public static float interpolate(float oldValue, float newValue, double interpolationValue) {
        return (float) (oldValue + (newValue - oldValue) * interpolationValue);
    }
}

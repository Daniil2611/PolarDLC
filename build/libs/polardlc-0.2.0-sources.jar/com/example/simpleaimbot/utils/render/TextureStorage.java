package com.example.simpleaimbot.utils.render;

import net.minecraft.class_2960;

public class TextureStorage {
    public static final class_2960 TOTEM = class_2960.method_60654("textures/item/totem_of_undying.png");
    public static final class_2960 HEART = class_2960.method_60654("textures/gui/sprites/hud/heart/container.png");
    public static final class_2960 POLAR_WATERMARK = class_2960.method_60655("simpleaimbot", "textures/gui/polar_p_64.png");
    public static final class_2960 SPIRIT_GHOST = class_2960.method_60655("simpleaimbot", "textures/gui/firefly.png");
    public static final class_2960 SPIRIT_WISP = class_2960.method_60655("simpleaimbot", "textures/gui/spirit_wisp.png");
    public static final class_2960 SPIRIT_FLAME = class_2960.method_60655("simpleaimbot", "textures/gui/spirit_flame.png");

    private TextureStorage() {
    }
}

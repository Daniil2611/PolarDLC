package com.example.simpleaimbot.utils;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_3532;

public class TargetUtils {
    public static boolean isValidTarget(class_1657 player, class_1297 entity) {
        if (!(entity instanceof class_1309 living)) return false;
        if (living == player) return false;
        if (!living.method_5805()) return false;
        // Если хотите разрешить мобов, замените следующую строку на return true;
        return living instanceof class_1657;
    }

    public static boolean canSee(class_1657 player, class_1297 target, boolean wallCheckEnabled) {
        if (!wallCheckEnabled) return true;
        return player.method_6057(target);
    }

    /**
     * Расстояние от игрока до ближайшей точки хитбокса цели.
     */
    public static double distanceToBoundingBox(class_1657 player, class_1297 target) {
        class_238 box = target.method_5829();
        double eyeY = player.method_23318() + player.method_18381(player.method_18376());
        double closestX = class_3532.method_15350(player.method_23317(), box.field_1323, box.field_1320);
        double closestY = class_3532.method_15350(eyeY, box.field_1322, box.field_1325);
        double closestZ = class_3532.method_15350(player.method_23321(), box.field_1321, box.field_1324);
        double dx = closestX - player.method_23317();
        double dy = closestY - eyeY;
        double dz = closestZ - player.method_23321();
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
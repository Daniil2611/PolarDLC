package com.example.simpleaimbot.utils;

import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class RotationUtils {

    public static float[] getRotationsToEntity(class_1657 player, class_1297 target, float basePrediction, float maxPrediction, Random random) {
        class_238 box = target.method_5829();
        class_243 eyePos = player.method_33571();

        double minY = box.field_1322;
        double maxY = box.field_1325 - 0.5;
        if (maxY < minY) maxY = minY;

        double targetY = minY + random.nextDouble() * (maxY - minY);
        double targetX = box.field_1323 + random.nextDouble() * (box.field_1320 - box.field_1323);
        double targetZ = box.field_1321 + random.nextDouble() * (box.field_1324 - box.field_1321);

        class_243 targetPos = new class_243(targetX, targetY, targetZ);

        class_243 velocity = target.method_18798();
        if (velocity.method_1027() > 0.01) {
            float predictionTime = basePrediction + random.nextFloat() * (maxPrediction - basePrediction);
            targetPos = targetPos.method_1019(velocity.method_1021(predictionTime));
        }

        class_243 toTarget = targetPos.method_1020(eyePos);
        double horizontalDistance = Math.sqrt(toTarget.field_1352 * toTarget.field_1352 + toTarget.field_1350 * toTarget.field_1350);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-toTarget.field_1352, toTarget.field_1350));
        float targetPitch = (float) Math.toDegrees(Math.atan2(-toTarget.field_1351, horizontalDistance));

        return new float[]{targetYaw, targetPitch};
    }

    public static float[] getRotationsToEntityCenter(class_1657 player, class_1297 target, float basePrediction, float maxPrediction, Random random) {
        class_238 box = target.method_5829();
        class_243 center = box.method_1005();

        class_243 velocity = target.method_18798();
        if (velocity.method_1027() > 0.01) {
            float predictionTime = basePrediction + random.nextFloat() * (maxPrediction - basePrediction);
            center = center.method_1019(velocity.method_1021(predictionTime));
        }

        class_243 eyePos = player.method_33571();
        class_243 toTarget = center.method_1020(eyePos);
        double horizontalDistance = Math.sqrt(toTarget.field_1352 * toTarget.field_1352 + toTarget.field_1350 * toTarget.field_1350);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-toTarget.field_1352, toTarget.field_1350));
        float targetPitch = (float) Math.toDegrees(Math.atan2(-toTarget.field_1351, horizontalDistance));

        return new float[]{targetYaw, targetPitch};
    }

    public static float[] getRotationsToBody(class_1657 player, class_1297 target, float basePrediction, float maxPrediction, Random random) {
        class_238 box = target.method_5829();
        class_243 eyePos = player.method_33571();

        double bodyY = box.field_1322 + (box.field_1325 - box.field_1322) * 0.55;
        double maxAllowedY = box.field_1325 - 0.5;
        if (bodyY > maxAllowedY) bodyY = maxAllowedY;

        double targetX = (box.field_1323 + box.field_1320) * 0.5;
        double targetZ = (box.field_1321 + box.field_1324) * 0.5;

        class_243 targetPos = new class_243(targetX, bodyY, targetZ);

        class_243 velocity = target.method_18798();
        if (velocity.method_1027() > 0.01) {
            float predictionTime = basePrediction + random.nextFloat() * (maxPrediction - basePrediction);
            targetPos = targetPos.method_1019(velocity.method_1021(predictionTime));
        }

        class_243 toTarget = targetPos.method_1020(eyePos);
        double horizontalDistance = Math.sqrt(toTarget.field_1352 * toTarget.field_1352 + toTarget.field_1350 * toTarget.field_1350);
        float targetYaw = (float) Math.toDegrees(Math.atan2(-toTarget.field_1352, toTarget.field_1350));
        float targetPitch = (float) Math.toDegrees(Math.atan2(-toTarget.field_1351, horizontalDistance));

        return new float[]{targetYaw, targetPitch};
    }

    public static float applyGcdFix(float delta, float mouseSensitivity) {
        float gcd = (float) (Math.pow(mouseSensitivity * 0.6 + 0.2, 3) * 1.2);
        return delta - (delta % gcd);
    }
}
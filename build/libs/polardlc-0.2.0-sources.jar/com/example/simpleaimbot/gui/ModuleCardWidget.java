package com.example.simpleaimbot.gui;

import com.example.simpleaimbot.utils.render.Render2DEngine;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_5481;
import net.minecraft.class_6382;

public class ModuleCardWidget extends class_339 {
    @FunctionalInterface
    public interface PressAction {
        void onPress(ModuleCardWidget widget);
    }

    private final String title;
    private final String description;
    private final Supplier<String> statusSupplier;
    private final BooleanSupplier activeSupplier;
    private final String actionHint;
    private final PressAction primaryAction;
    private final @Nullable PressAction secondaryAction;
    private final @Nullable class_2561 tooltip;

    private boolean selected;
    private float hoverProgress;
    private float selectedProgress;

    public ModuleCardWidget(int x, int y, int width, int height, String title, String description,
                            Supplier<String> statusSupplier, BooleanSupplier activeSupplier, String actionHint,
                            PressAction primaryAction, @Nullable PressAction secondaryAction, @Nullable class_2561 tooltip) {
        super(x, y, width, height, GuiTheme.uniform(title));
        this.title = title;
        this.description = description;
        this.statusSupplier = statusSupplier;
        this.activeSupplier = activeSupplier;
        this.actionHint = actionHint;
        this.primaryAction = primaryAction;
        this.secondaryAction = secondaryAction;
        this.tooltip = tooltip;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public @Nullable class_2561 getTooltipText() {
        return tooltip;
    }

    @Override
    protected void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 client = class_310.method_1551();
        boolean hovered = method_25405(mouseX, mouseY);
        boolean active = activeSupplier.getAsBoolean();

        hoverProgress = class_3532.method_16439(0.24f, hoverProgress, hovered ? 1.0f : 0.0f);
        selectedProgress = class_3532.method_16439(0.24f, selectedProgress, selected ? 1.0f : 0.0f);

        int accentColor = active ? GuiTheme.accentBright() : GuiTheme.accent();
        int fill = GuiTheme.mix(GuiTheme.panel(), GuiTheme.withAlpha(accentColor, 255), 0.06f + selectedProgress * 0.12f);
        int border = GuiTheme.mix(GuiTheme.withAlpha(GuiTheme.text(), 22), GuiTheme.withAlpha(accentColor, 168),
                0.20f + selectedProgress * 0.55f + hoverProgress * 0.18f);
        int glow = GuiTheme.withAlpha(accentColor, 8 + Math.round(12 * hoverProgress + 18 * selectedProgress));

        Render2DEngine.drawBlurredShadow(context.method_51448(), method_46426(), method_46427(), field_22758, field_22759, 3, new Color(glow, true));
        Render2DEngine.drawRound(context.method_51448(), method_46426(), method_46427(), field_22758, field_22759, 16, new Color(GuiTheme.withAlpha(border, 132), true));
        Render2DEngine.drawRound(context.method_51448(), method_46426() + 1, method_46427() + 1, field_22758 - 2.0f, field_22759 - 2.0f, 15, new Color(fill, true));
        Render2DEngine.drawRound(context.method_51448(), method_46426() + 2, method_46427() + 2, field_22758 - 4.0f, field_22759 - 4.0f, 14,
                new Color(GuiTheme.mix(fill, 0xFFFFFFFF, 0.02f + hoverProgress * 0.04f), true));

        Render2DEngine.drawRound(context.method_51448(), method_46426() + 10, method_46427() + 12, 4.0f, field_22759 - 24.0f, 2.0f,
                new Color(GuiTheme.withAlpha(accentColor, active ? 240 : 110), true));

        String status = statusSupplier.get();
        int badgeWidth = Math.max(44, client.field_1772.method_27525(GuiTheme.uniform(status)) + 16);
        int badgeX = method_46426() + field_22758 - badgeWidth - 12;
        int badgeY = method_46427() + 12;
        int badgeFill = active
                ? GuiTheme.withAlpha(accentColor, 168)
                : GuiTheme.withAlpha(GuiTheme.panelAlt(), 214);
        int badgeEdge = active
                ? GuiTheme.withAlpha(GuiTheme.accentBright(), 178)
                : GuiTheme.withAlpha(GuiTheme.text(), 28);

        int titleWidth = Math.max(20, badgeX - (method_46426() + 24) - 8);
        class_2561 titleText = GuiTheme.uniform(client.field_1772.method_27523(title, titleWidth));
        class_2561 statusText = GuiTheme.uniform(status);
        class_2561 hintText = GuiTheme.uniform(client.field_1772.method_27523(actionHint, field_22758 - 36));
        List<class_5481> descriptionLines = client.field_1772.method_1728(GuiTheme.uniform(description), Math.max(22, field_22758 - 48));

        context.method_27535(client.field_1772, titleText, method_46426() + 24, method_46427() + 12, GuiTheme.text());

        int descriptionY = method_46427() + 28;
        for (int i = 0; i < Math.min(2, descriptionLines.size()); i++) {
            context.method_51430(client.field_1772, descriptionLines.get(i), method_46426() + 24, descriptionY, GuiTheme.mutedText(), false);
            descriptionY += client.field_1772.field_2000 + 1;
        }

        context.method_51439(client.field_1772, hintText, method_46426() + 24, method_46427() + field_22759 - 17,
                GuiTheme.withAlpha(GuiTheme.accentBright(), 214), false);

        GuiTheme.drawCard(context, badgeX, badgeY, badgeWidth, 18, badgeFill, badgeEdge, 9);
        context.method_27534(client.field_1772, statusText, badgeX + badgeWidth / 2, badgeY + 5, GuiTheme.text());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || !method_25405(mouseX, mouseY)) {
            return false;
        }

        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            method_25354(class_310.method_1551().method_1483());
            primaryAction.onPress(this);
            return true;
        }

        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && secondaryAction != null) {
            method_25354(class_310.method_1551().method_1483());
            secondaryAction.onPress(this);
            return true;
        }

        return false;
    }

    @Override
    protected void method_47399(class_6382 builder) {
        method_37021(builder);
    }
}

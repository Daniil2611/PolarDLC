package com.example.simpleaimbot.gui;

import com.example.simpleaimbot.utils.render.Render2DEngine;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;

public class ModernButtonWidget extends class_4185 {
    @FunctionalInterface
    public interface SecondaryPressAction {
        void onSecondaryPress(ModernButtonWidget button);
    }

    public enum Variant {
        TAB,
        PRIMARY,
        SECONDARY,
        UTILITY,
        COLOR
    }

    private @Nullable class_2561 tooltip;
    private Variant variant = Variant.PRIMARY;
    private boolean visualActive;
    private float hoverProgress;
    private float activeProgress;
    private int accentColor = GuiTheme.accent();
    private @Nullable SecondaryPressAction secondaryPressAction;

    public ModernButtonWidget(int x, int y, int width, int height, class_2561 message, class_4241 onPress) {
        super(x, y, width, height, message, onPress, button -> class_2561.method_43473());
    }

    public ModernButtonWidget withTooltip(class_2561 tooltip) {
        this.tooltip = tooltip;
        return this;
    }

    public ModernButtonWidget withVariant(Variant variant) {
        this.variant = variant;
        return this;
    }

    public ModernButtonWidget withActive(boolean active) {
        this.visualActive = active;
        return this;
    }

    public ModernButtonWidget withAccentColor(int color) {
        this.accentColor = color;
        return this;
    }

    public void setVisualActive(boolean active) {
        this.visualActive = active;
    }

    public void setAccentColor(int color) {
        this.accentColor = color;
    }

    public ModernButtonWidget withSecondaryAction(SecondaryPressAction action) {
        this.secondaryPressAction = action;
        return this;
    }

    @Nullable
    public class_2561 getTooltipText() {
        return tooltip;
    }

    @Override
    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        boolean hovered = method_25405(mouseX, mouseY);
        hoverProgress = class_3532.method_16439(0.28f, hoverProgress, hovered ? 1.0f : 0.0f);
        activeProgress = class_3532.method_16439(0.24f, activeProgress, visualActive ? 1.0f : 0.0f);

        int baseColor = baseColor();
        int borderColor = borderColor();
        int shadowColor = GuiTheme.withAlpha(GuiTheme.mix(accentColor, GuiTheme.accentBright(), hoverProgress), (int) (8 + 16 * hoverProgress + 20 * activeProgress));
        int fillColor = GuiTheme.mix(baseColor, accentColor, 0.08f * hoverProgress + 0.18f * activeProgress);

        Render2DEngine.drawBlurredShadow(context.method_51448(), method_46426(), method_46427(), field_22758, field_22759, 3, new Color(shadowColor, true));
        Render2DEngine.drawRound(context.method_51448(), method_46426(), method_46427(), field_22758, field_22759, radius(), new Color(GuiTheme.withAlpha(borderColor, 128), true));
        Render2DEngine.drawRound(context.method_51448(), method_46426() + 1, method_46427() + 1, field_22758 - 2.0f, field_22759 - 2.0f, Math.max(1, radius() - 1),
                new Color(fillColor, true));
        Render2DEngine.drawRound(context.method_51448(), method_46426() + 2, method_46427() + 2, field_22758 - 4.0f, field_22759 - 4.0f, Math.max(1, radius() - 2),
                new Color(GuiTheme.mix(fillColor, 0xFFFFFFFF, 0.03f + hoverProgress * 0.05f), true));

        if (visualActive) {
            Render2DEngine.drawRound(context.method_51448(), method_46426() + 4, method_46427() + field_22759 - 5, field_22758 - 8.0f, 2.0f, 1.0f,
                    new Color(GuiTheme.withAlpha(accentColor, 230), true));
        } else if (variant == Variant.TAB) {
            Render2DEngine.drawRound(context.method_51448(), method_46426() + 5, method_46427() + field_22759 - 4, field_22758 - 10.0f, 1.0f, 1.0f,
                    new Color(GuiTheme.withAlpha(GuiTheme.text(), hovered ? 70 : 26), true));
        }

        if (variant == Variant.COLOR) {
            Render2DEngine.drawRound(context.method_51448(), method_46426() + field_22758 - 19, method_46427() + field_22759 / 2.0f - 6, 12.0f, 12.0f, 6.0f,
                    new Color(GuiTheme.withAlpha(0xFFFFFFFF, 90), true));
            Render2DEngine.drawRound(context.method_51448(), method_46426() + field_22758 - 18, method_46427() + field_22759 / 2.0f - 5, 10.0f, 10.0f, 5.0f,
                    new Color(accentColor, true));
        }

        class_310 client = class_310.method_1551();
        int maxTextWidth = Math.max(24, field_22758 - 20 - (variant == Variant.COLOR ? 16 : 0));
        String label = client.field_1772.method_27523(method_25369().getString(), maxTextWidth);
        class_2561 buttonText = GuiTheme.uniform(label);
        int textColor = GuiTheme.mix(GuiTheme.mutedText(), GuiTheme.text(), 0.45f + hoverProgress * 0.25f + activeProgress * 0.35f);
        int textX = method_46426() + field_22758 / 2 - (variant == Variant.COLOR ? 8 : 0);
        context.method_27534(client.field_1772, buttonText, textX, method_46427() + (field_22759 - 8) / 2, textColor);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT && field_22763 && field_22764 && method_25405(mouseX, mouseY) && secondaryPressAction != null) {
            method_25354(class_310.method_1551().method_1483());
            secondaryPressAction.onSecondaryPress(this);
            return true;
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    private int baseColor() {
        return switch (variant) {
            case TAB -> GuiTheme.mix(GuiTheme.panelAlt(), 0xFF090B10, 0.32f);
            case SECONDARY -> GuiTheme.mix(GuiTheme.panel(), 0xFF0E1219, 0.36f);
            case UTILITY -> GuiTheme.mix(GuiTheme.panel(), 0xFF11151C, 0.30f);
            case COLOR -> GuiTheme.mix(GuiTheme.panelAlt(), 0xFF0D1017, 0.34f);
            case PRIMARY -> GuiTheme.mix(GuiTheme.panel(), 0xFF10141C, 0.24f);
        };
    }

    private int borderColor() {
        int borderBase = switch (variant) {
            case TAB -> GuiTheme.withAlpha(GuiTheme.text(), 26);
            case SECONDARY -> GuiTheme.withAlpha(GuiTheme.text(), 20);
            case UTILITY -> GuiTheme.withAlpha(GuiTheme.danger(), 46);
            case COLOR -> GuiTheme.withAlpha(accentColor, 96);
            case PRIMARY -> GuiTheme.withAlpha(GuiTheme.accent(), 34);
        };
        return GuiTheme.mix(borderBase, GuiTheme.withAlpha(accentColor, 170), 0.32f * hoverProgress + 0.50f * activeProgress);
    }

    private int radius() {
        return variant == Variant.TAB ? 10 : 12;
    }
}

package com.example.simpleaimbot.mixin;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import net.minecraft.class_1306;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_759.class)
public class HeldItemRendererMixin {

    @Overwrite
    private void swingArm(float swingProgress, float equipProgress, class_4587 matrices, int direction, class_1306 arm) {
        ModConfig config = ConfigManager.getConfig();
        if (config.swingAnimationEnabled && arm == class_1306.field_6183) {
            float progress = class_3532.method_15363(swingProgress, 0.0F, 1.0F);
            switch (config.swingAnimationStyle) {
                case 1 -> styleLunar(progress, matrices, direction);
                case 3 -> styleVelocity(progress, matrices, direction);
                default -> styleEleven(progress, matrices, direction);
            }
            return;
        }

        applyEquipOffset(matrices, arm, equipProgress);
        float h = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * (float) Math.PI);
        float j = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * ((float) Math.PI * 2F));
        float k = -0.2F * class_3532.method_15374(swingProgress * (float) Math.PI);
        matrices.method_46416((float) direction * h, j, k);
        applySwingOffset(matrices, arm, swingProgress);
    }

    @Unique
    private void styleVelocity(float progress, class_4587 matrices, int direction) {
        float root = class_3532.method_15374(class_3532.method_15355(progress) * (float) Math.PI);
        float wave = class_3532.method_15374(progress * (float) Math.PI);
        applyStyleBase(matrices, direction);
        matrices.method_46416(direction * 0.018F * root, 0.010F * wave, 0.022F * root);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(32.0F + root * 10.0F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-50.0F + wave * 6.0F));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(70.0F + root * 10.0F));
    }

    @Unique
    private void styleEleven(float progress, class_4587 matrices, int direction) {
        float root = class_3532.method_15374(class_3532.method_15355(progress) * (float) Math.PI);
        applyStyleBase(matrices, direction);
        matrices.method_46416(direction * 0.010F * root, 0.012F * root, 0.018F * root);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(28.0F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-44.0F + root * 3.0F));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(86.0F + root * 10.0F));
    }

    @Unique
    private void styleLunar(float progress, class_4587 matrices, int direction) {
        float root = class_3532.method_15374(class_3532.method_15355(progress) * (float) Math.PI);
        float wave = class_3532.method_15374(progress * (float) Math.PI);
        applyStyleBase(matrices, direction);
        matrices.method_46416(direction * -0.015F * root, 0.020F * root, 0.014F * wave);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(34.0F + root * 10.0F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(-58.0F - root * 6.0F));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(96.0F + wave * 8.0F));
    }

    @Unique
    private void applyStyleBase(class_4587 matrices, int direction) {
        matrices.method_46416(0.58F * direction, -0.44F, -0.92F);
    }

    @Unique
    private void applyEquipOffset(class_4587 matrices, class_1306 arm, float equipProgress) {
        int i = arm == class_1306.field_6183 ? 1 : -1;
        matrices.method_46416((float) i * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
    }

    @Unique
    private void applySwingOffset(class_4587 matrices, class_1306 arm, float swingProgress) {
        int i = arm == class_1306.field_6183 ? 1 : -1;
        float g = class_3532.method_15374(swingProgress * swingProgress * (float) Math.PI);
        matrices.method_22907(class_7833.field_40716.rotationDegrees((float) i * (45.0F + g * -20.0F)));
        float h = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float) Math.PI);
        matrices.method_22907(class_7833.field_40718.rotationDegrees((float) i * h * -20.0F));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(h * -80.0F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees((float) i * -45.0F));
    }
}

package com.example.simpleaimbot.mixin;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.utils.InventoryMoveHelper;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_2815;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class ClientConnectionMixin {

    @Inject(method = "send", at = @At("HEAD"), cancellable = true)
    private void onSendPacket(class_2596<?> packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;
        if (player == null) return;

        if (ConfigManager.getConfig().inventoryMoveEnabled) {
            if (client.field_1755 != null && packet instanceof class_2813) {
                boolean isMoving = player.field_3913.field_3905 != 0 || player.field_3913.field_3907 != 0;
                if (isMoving) {
                    InventoryMoveHelper.storePacket((class_2813) packet);
                    ci.cancel();
                }
            }

            if (packet instanceof class_2815) {
                if (!InventoryMoveHelper.pendingClicks.isEmpty()) {
                    InventoryMoveHelper.scheduleClose();
                    ci.cancel();
                }
            }
        }
    }
}
package com.example.simpleaimbot.mixin;

import com.example.simpleaimbot.config.ConfigManager;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1309.class)
public class ClientPlayerSwingMixin {

    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void polardlc$slowSwing(CallbackInfoReturnable<Integer> cir) {
        class_1309 self = (class_1309) (Object) this;
        if (self instanceof class_746 player
                && class_310.method_1551().field_1724 == player
                && ConfigManager.getConfig().swingAnimationEnabled) {
            cir.setReturnValue(12);
        }
    }
}

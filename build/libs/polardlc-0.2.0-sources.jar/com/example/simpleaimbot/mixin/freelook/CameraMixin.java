package com.example.simpleaimbot.mixin.freelook;

import com.example.simpleaimbot.freelook.freelook.CameraOverriddenEntity;
import com.example.simpleaimbot.freelook.freelook.FreeLookMod;
import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraMixin {
    @Unique
    private boolean firstTime = true;

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V", shift = At.Shift.AFTER))
    private void onUpdate(class_1922 blockView, class_1297 entity, boolean bl, boolean bl2, float f, CallbackInfo ci) {
        if (FreeLookMod.isFreeLooking && entity instanceof class_746) {
            if (entity instanceof CameraOverriddenEntity cameraOverriddenEntity) {
                if (firstTime && class_310.method_1551().field_1724 != null) {
                    cameraOverriddenEntity.freelook$setCameraPitch(class_310.method_1551().field_1724.method_36455());
                    cameraOverriddenEntity.freelook$setCameraYaw(class_310.method_1551().field_1724.method_36454());
                    firstTime = false;
                }
                this.setRotation(cameraOverriddenEntity.freelook$getCameraYaw(), cameraOverriddenEntity.freelook$getCameraPitch());
            }
        }
        if (!FreeLookMod.isFreeLooking && entity instanceof class_746) {
            firstTime = true;
        }
    }
}
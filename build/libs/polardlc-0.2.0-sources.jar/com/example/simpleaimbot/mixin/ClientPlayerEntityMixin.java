package com.example.simpleaimbot.mixin;

import com.example.simpleaimbot.freelook.freelook.CameraOverriddenEntity;
import com.example.simpleaimbot.freelook.freelook.FreeLookMod;
import com.example.simpleaimbot.modules.KillAura;
import com.example.simpleaimbot.utils.InventoryMoveHelper;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tickMovement", at = @At("HEAD"), cancellable = true)
    private void onTickMovement(CallbackInfo ci) {
        if (InventoryMoveHelper.freezeMovement) {
            ci.cancel();
            return;
        }

        class_310 client = class_310.method_1551();
        class_746 player = (class_746) (Object) this;
        if (!FreeLookMod.isAutoFreeLooking()
                || player.method_3144()
                || client == null
                || !KillAura.hasTargetInRange()
                || !(player instanceof CameraOverriddenEntity cameraOverriddenEntity)) {
            return;
        }

        float movementForward = player.field_3913.field_3905;
        float movementSideways = player.field_3913.field_3907;
        if (movementForward == 0.0f && movementSideways == 0.0f) {
            return;
        }

        float delta = class_3532.method_15393(player.method_36454() - cameraOverriddenEntity.freelook$getCameraYaw()) * class_3532.field_29847;
        float cos = class_3532.method_15362(delta);
        float sin = class_3532.method_15374(delta);

        player.field_3913.field_3905 = movementForward * cos - movementSideways * sin;
        player.field_3913.field_3907 = movementForward * sin + movementSideways * cos;
    }
}
package com.example.simpleaimbot.rendering;

import com.example.simpleaimbot.config.ConfigManager;
import com.example.simpleaimbot.config.ModConfig;
import com.example.simpleaimbot.utils.render.TextureStorage;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class TargetESPRenderer {
    private static final long INIT_TIME = System.currentTimeMillis();
    private static final int SPIRIT_COUNT = 4;

    public static void render(WorldRenderContext context, Entity target) {
        ModConfig config = ConfigManager.getConfig();
        if (!config.targetEspEnabled || target == null || !target.isAlive()) {
            return;
        }

        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            return;
        }

        float tickDelta = context.tickCounter().getTickDelta(true);
        Vec3d cameraPos = context.camera().getPos();
        double x = MathHelper.lerp(tickDelta, target.prevX, target.getX()) - cameraPos.x;
        double y = MathHelper.lerp(tickDelta, target.prevY, target.getY()) - cameraPos.y;
        double z = MathHelper.lerp(tickDelta, target.prevZ, target.getZ()) - cameraPos.z;
        float height = target.getHeight();
        float radius = Math.max(0.42f, target.getWidth() * 0.75f);
        float time = (System.currentTimeMillis() - INIT_TIME) / 1000.0f;

        matrices.push();
        matrices.translate(x, y, z);

        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.disableDepthTest();
        if (config.targetEspMode == ModConfig.TargetEspMode.SPIRITS) {
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
            drawSpirits(matrices.peek().getPositionMatrix(), radius, height, config.targetEspColor, time);
            RenderSystem.defaultBlendFunc();
        } else {
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            switch (config.targetEspMode) {
                case RING_STACK -> drawRingStack(matrices.peek().getPositionMatrix(), radius, height, config.targetEspColor, time);
                case CYLINDER -> drawCylinder(matrices.peek().getPositionMatrix(), radius, height, config.targetEspColor, time);
                case SPIRAL -> drawSpiral(matrices.peek().getPositionMatrix(), radius, height, config.targetEspColor, time);
                case SPIRITS -> { }
            }
        }

        RenderSystem.enableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
        matrices.pop();
    }

    private static void drawSpiral(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        for (int orbit = 0; orbit < 3; orbit++) {
            BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= 140; i++) {
                float progress = i / 140.0f;
                double angle = time * 5.0 + progress * Math.PI * 4.0 + orbit * (Math.PI * 2.0 / 3.0);
                float y = height * (1.0f - progress);
                float wobble = radius + 0.04f * (float) Math.sin(time * 6.0 + progress * 8.0);
                float x = (float) Math.cos(angle) * wobble;
                float z = (float) Math.sin(angle) * wobble;
                int outer = withAlpha(baseColor, Math.round(180 * (1.0f - progress)));
                int inner = withAlpha(baseColor, Math.round(24 * (1.0f - progress)));
                buffer.vertex(matrix, x * 1.06f, y, z * 1.06f).color(outer);
                buffer.vertex(matrix, x * 0.92f, y + 0.04f, z * 0.92f).color(inner);
            }
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        }
    }

    private static void drawRingStack(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        for (int i = 0; i < 3; i++) {
            float offset = i / 2.0f;
            float y = height * (0.18f + 0.32f * i) + (float) Math.sin(time * 2.5f + i) * 0.04f;
            float localRadius = radius + 0.05f * i + (float) Math.sin(time * 3.5f + i) * 0.03f;
            drawRingBand(matrix,
                    Math.max(0.04f, localRadius - 0.06f),
                    localRadius + 0.02f,
                    y,
                    withAlpha(baseColor, Math.round(165 - offset * 32)),
                    withAlpha(baseColor, 0),
                    72);
        }
    }

    private static void drawCylinder(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        float pulse = 0.04f * (float) Math.sin(time * 4.0f);
        for (int i = 0; i <= 72; i++) {
            double angle = Math.PI * 2 * i / 72.0;
            float x = (float) Math.cos(angle) * (radius + pulse);
            float z = (float) Math.sin(angle) * (radius + pulse);
            buffer.vertex(matrix, x, 0.02f, z).color(withAlpha(baseColor, 18));
            buffer.vertex(matrix, x, height + 0.02f, z).color(withAlpha(baseColor, 135));
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        drawRingBand(matrix, Math.max(0.03f, radius - 0.05f), radius + 0.02f, 0.04f, withAlpha(baseColor, 120), withAlpha(baseColor, 0), 72);
        drawRingBand(matrix, Math.max(0.03f, radius - 0.05f), radius + 0.02f, height, withAlpha(baseColor, 190), withAlpha(baseColor, 0), 72);
    }

    private static void drawSpirits(Matrix4f matrix, float radius, float height, int baseColor, float time) {
        int userColor = 0xFF000000 | (baseColor & 0x00FFFFFF);
        int violet = mixColor(0xFF7A2BFF, userColor, 0.35f);
        int pink = mixColor(0xFFFF56EA, userColor, 0.22f);
        int glowColor = mixColor(violet, pink, 0.42f);
        int coreColor = mixColor(glowColor, 0xFFFFFFFF, 0.82f);
        float tau = (float) (Math.PI * 2.0);
        float orbit = radius + 0.36f;
        float minY = height * 0.08f;
        float maxY = height * 0.90f;

        for (int i = 0; i < SPIRIT_COUNT; i++) {
            float phase = time * 0.92f + i * (tau / SPIRIT_COUNT);
            float x = (float) Math.cos(phase) * orbit;
            float z = (float) Math.sin(phase) * orbit;
            float y = MathHelper.clamp(height * (0.32f + 0.16f * i) + 0.07f * (float) Math.sin(time * 1.6f + i), minY, maxY);

            float halo = 0.33f + 0.03f * (float) Math.sin(time * 2.1f + i);
            float orb = 0.15f + 0.01f * (float) Math.cos(time * 2.8f + i);
            drawSpiritOrb(matrix, x, y, z, halo, withAlpha(violet, 120));
            drawSpiritOrb(matrix, x, y, z, halo * 0.68f, withAlpha(pink, 188));
            drawSpiritOrb(matrix, x, y, z, orb, withAlpha(glowColor, 236));
            drawSpiritOrb(matrix, x, y, z, orb * 0.56f, withAlpha(coreColor, 255));

            // Add short echo blobs behind each spirit like in the reference.
            for (int t = 1; t <= 3; t++) {
                float echoPhase = phase - t * 0.22f;
                float ex = (float) Math.cos(echoPhase) * (orbit - 0.02f * t);
                float ez = (float) Math.sin(echoPhase) * (orbit - 0.02f * t);
                float ey = MathHelper.clamp(y - 0.03f * t, minY, maxY);
                float fade = 1.0f - t / 3.6f;
                drawSpiritOrb(matrix, ex, ey, ez, (0.14f - t * 0.02f), withAlpha(violet, Math.round(90 * fade)));
                drawSpiritOrb(matrix, ex, ey, ez, (0.08f - t * 0.012f), withAlpha(pink, Math.round(128 * fade)));
            }
        }
    }

    private static void drawRingBand(Matrix4f matrix, float innerRadius, float outerRadius, float yOffset,
                                     int outerColor, int innerColor, int segments) {
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            double angle = Math.PI * 2 * i / segments;
            float x = (float) Math.cos(angle);
            float z = (float) Math.sin(angle);
            buffer.vertex(matrix, x * outerRadius, yOffset, z * outerRadius).color(outerColor);
            buffer.vertex(matrix, x * innerRadius, yOffset, z * innerRadius).color(innerColor);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static void drawSpiritWisp(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                       float width, float height, int centerColor, int edgeColor) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_WISP);
        drawTexturedCross(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
    }

    private static void drawSpiritOrb(Matrix4f matrix, float centerX, float centerY, float centerZ, float size, int color) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_WISP);
        drawTexturedCross(matrix, centerX, centerY, centerZ, size, size, color, withAlpha(color, 0));
    }

    private static void drawSpiritFlame(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                        float width, float height, int color) {
        RenderSystem.setShaderTexture(0, TextureStorage.SPIRIT_FLAME);
        drawTexturedCross(matrix, centerX, centerY, centerZ, width, height, color, withAlpha(color, 0));
    }

    private static void drawTexturedCross(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                          float width, float height, int centerColor, int edgeColor) {
        drawTexturedPlaneX(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
        drawTexturedPlaneZ(matrix, centerX, centerY, centerZ, width, height, centerColor, edgeColor);
    }

    private static void drawTexturedPlaneX(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                           float width, float height, int centerColor, int edgeColor) {
        float halfWidth = width * 0.5f;
        float halfHeight = height * 0.5f;
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, centerX - halfWidth, centerY - halfHeight, centerZ).texture(0.0f, 1.0f).color(edgeColor);
        buffer.vertex(matrix, centerX - halfWidth, centerY + halfHeight, centerZ).texture(0.0f, 0.0f).color(centerColor);
        buffer.vertex(matrix, centerX + halfWidth, centerY + halfHeight, centerZ).texture(1.0f, 0.0f).color(centerColor);
        buffer.vertex(matrix, centerX + halfWidth, centerY - halfHeight, centerZ).texture(1.0f, 1.0f).color(edgeColor);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static void drawTexturedPlaneZ(Matrix4f matrix, float centerX, float centerY, float centerZ,
                                           float width, float height, int centerColor, int edgeColor) {
        float halfWidth = width * 0.5f;
        float halfHeight = height * 0.5f;
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, centerX, centerY - halfHeight, centerZ - halfWidth).texture(0.0f, 1.0f).color(edgeColor);
        buffer.vertex(matrix, centerX, centerY + halfHeight, centerZ - halfWidth).texture(0.0f, 0.0f).color(centerColor);
        buffer.vertex(matrix, centerX, centerY + halfHeight, centerZ + halfWidth).texture(1.0f, 0.0f).color(centerColor);
        buffer.vertex(matrix, centerX, centerY - halfHeight, centerZ + halfWidth).texture(1.0f, 1.0f).color(edgeColor);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private static int mixColor(int first, int second, float progress) {
        progress = MathHelper.clamp(progress, 0.0f, 1.0f);
        int r1 = (first >>> 16) & 0xFF;
        int g1 = (first >>> 8) & 0xFF;
        int b1 = first & 0xFF;
        int r2 = (second >>> 16) & 0xFF;
        int g2 = (second >>> 8) & 0xFF;
        int b2 = second & 0xFF;

        int r = Math.round(r1 + (r2 - r1) * progress);
        int g = Math.round(g1 + (g2 - g1) * progress);
        int b = Math.round(b1 + (b2 - b1) * progress);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }
}
